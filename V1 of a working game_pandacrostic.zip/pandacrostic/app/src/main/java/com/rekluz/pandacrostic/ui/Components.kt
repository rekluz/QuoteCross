package com.rekluz.pandacrostic.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
// CRITICAL IMPORTS FOR VIEWMODEL & RECENT ERRORS
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rekluz.pandacrostic.model.CrissCrossLevel
import com.rekluz.pandacrostic.model.PuzzleRepository
import com.rekluz.pandacrostic.viewmodel.GameViewModel

@Composable
fun AppNavigator() {
    var screen by remember { mutableStateOf("HOME") }
    var levelIndex by remember { mutableIntStateOf(0) }

    when (screen) {
        "HOME" -> HomeScreen(
            onPlay3x3 = { screen = "3X3"; levelIndex = 0 },
            onPlay5x5 = { screen = "5X5"; levelIndex = 0 }
        )
        "3X3" -> PandaCrosticGame(
            level = PuzzleRepository.levels3x3[levelIndex],
            title = "3×3 - Level ${levelIndex + 1}",
            onNext = { if (levelIndex < PuzzleRepository.levels3x3.size - 1) levelIndex++ else screen = "HOME" },
            onHome = { screen = "HOME" }
        )
        "5X5" -> PandaCrosticGame(
            level = PuzzleRepository.levels5x5[levelIndex],
            title = "5×5 - Level ${levelIndex + 1}",
            onNext = { if (levelIndex < PuzzleRepository.levels5x5.size - 1) levelIndex++ else screen = "HOME" },
            onHome = { screen = "HOME" }
        )
    }
}

@Composable
fun HomeScreen(onPlay3x3: () -> Unit, onPlay5x5: () -> Unit) {
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp.dp >= 600.dp
    val infiniteTransition = rememberInfiniteTransition(label = "panda")
    val pandaScale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(2000), RepeatMode.Reverse), label = ""
    )

    Box(Modifier.fillMaxSize().background(Color(0xFFE3F2FD)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🐼", fontSize = 100.sp, modifier = Modifier.graphicsLayer { scaleX = pandaScale; scaleY = pandaScale })
            Text("Pand-A-crostic", fontSize = 42.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
            Spacer(Modifier.height(40.dp))
            Button(onClick = onPlay3x3, modifier = Modifier.width(260.dp)) { Text("Play 3x3") }
            Spacer(Modifier.height(16.dp))
            Button(onClick = onPlay5x5, modifier = Modifier.width(260.dp)) { Text("Play 5x5") }
        }
    }
}

@Composable
fun PandaCrosticGame(
    level: CrissCrossLevel,
    title: String,
    onNext: () -> Unit,
    onHome: () -> Unit,
    gameViewModel: GameViewModel = viewModel() // This hooks up your GameViewModel.kt
) {
    // When the level changes, reset the tiles in the ViewModel
    LaunchedEffect(level) {
        gameViewModel.initLevel(level)
    }

    Scaffold(
        bottomBar = {
            Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onHome, modifier = Modifier.weight(1f)) { Text("Home") }
                if (gameViewModel.isSolved) {
                    Button(onClick = onNext, modifier = Modifier.weight(1f)) { Text("Next Level") }
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(24.dp))

            // Grid
            Column {
                for (r in 0 until level.gridSize) {
                    Row {
                        for (c in 0 until level.gridSize) {
                            val idx = r * level.gridSize + c
                            val char = gameViewModel.tiles.getOrNull(idx) ?: ""
                            val isBlank = char == "_"
                            val isCorrect = !isBlank && char == level.solvedChars[idx]
                            val isSelected = gameViewModel.selectedIndex == idx

                            Box(
                                modifier = Modifier
                                    .size(50.dp).padding(2.dp)
                                    .background(
                                        when {
                                            isBlank -> Color.DarkGray
                                            isCorrect -> Color(0xFF4CAF50)
                                            isSelected -> Color(0xFF00BCD4)
                                            else -> Color(0xFFE0E0E0)
                                        },
                                        RoundedCornerShape(4.dp)
                                    )
                                    .clickable(enabled = !isCorrect && !isBlank && !gameViewModel.isSolved) {
                                        gameViewModel.handleTileClick(idx, level)
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (!isBlank) {
                                    Text(text = char, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Clues
            Row(Modifier.fillMaxWidth().padding(top = 24.dp).verticalScroll(rememberScrollState())) {
                Column(Modifier.weight(1f)) {
                    Text("ACROSS", fontWeight = FontWeight.Bold)
                    level.acrossClues.forEach { Text("${it.first}: ${it.second}", fontSize = 14.sp) }
                }
                Column(Modifier.weight(1f)) {
                    Text("DOWN", fontWeight = FontWeight.Bold)
                    level.downClues.forEach { Text("${it.first}: ${it.second}", fontSize = 14.sp) }
                }
            }
        }
    }
}