package com.rekluz.pandacrostic.model

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf

data class GridCell(
    val row: Int,
    val col: Int,
    val solution: String,
    var userValue: MutableState<String> = mutableStateOf(""),
    val number: Int? = null,
    val isBlackSquare: Boolean = false
)