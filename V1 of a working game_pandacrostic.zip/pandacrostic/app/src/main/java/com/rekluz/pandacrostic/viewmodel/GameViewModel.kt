package com.rekluz.pandacrostic.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.rekluz.pandacrostic.model.CrissCrossLevel

class GameViewModel : ViewModel() {
    // These variables hold the "Live" state of the game
    var tiles by mutableStateOf<List<String>>(emptyList())
    var selectedIndex by mutableStateOf<Int?>(null)
    var isSolved by mutableStateOf(false)

    // This sets up a new level
    fun initLevel(level: CrissCrossLevel) {
        val blank = "_"
        val letterIndices = level.solvedChars.indices.filter { level.solvedChars[it] != blank }
        val shuffledLetters = letterIndices.map { level.solvedChars[it] }.shuffled()
        val result = level.solvedChars.toMutableList()

        letterIndices.forEachIndexed { i, originalIdx ->
            result[originalIdx] = shuffledLetters[i]
        }

        tiles = result.toList()
        selectedIndex = null
        isSolved = false
    }

    // This handles the clicking and swapping logic
    fun handleTileClick(clickedIdx: Int, level: CrissCrossLevel) {
        val char = tiles[clickedIdx]
        if (char == "_" || tiles[clickedIdx] == level.solvedChars[clickedIdx] || isSolved) return

        if (selectedIndex == null) {
            selectedIndex = clickedIdx
        } else {
            val newList = tiles.toMutableList()
            val temp = newList[selectedIndex!!]
            newList[selectedIndex!!] = newList[clickedIdx]
            newList[clickedIdx] = temp
            tiles = newList.toList()
            selectedIndex = null

            // Check if they won!
            if (tiles == level.solvedChars) {
                isSolved = true
            }
        }
    }
}