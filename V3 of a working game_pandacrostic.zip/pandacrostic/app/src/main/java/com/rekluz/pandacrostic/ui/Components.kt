package com.rekluz.pandacrostic.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer // Added this import
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rekluz.pandacrostic.model.CrissCrossLevel
import com.rekluz.pandacrostic.model.GridCell
import com.rekluz.pandacrostic.model.PuzzleRepository
import com.rekluz.pandacrostic.viewmodel.GameState
import com.rekluz.pandacrostic.viewmodel.GameViewModel

@Composable
fun MainContent(viewModel: GameViewModel) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF0F4F0) // Light Bamboo White
    ) {
        when (viewModel.currentState) {
            GameState.MENU -> MenuScreen(viewModel)
            GameState.PLAYING -> GameScreen(viewModel)
        }
    }
}

@Composable
fun MenuScreen(viewModel: GameViewModel) {
    val infiniteTransition = rememberInfiniteTransition(label = "PandaBreath")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "scale"
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "🐼",
            fontSize = 80.sp,
            modifier = Modifier.graphicsLayer(scaleX = scale, scaleY = scale)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "PandaCrostic",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF2E7D32)
        )
        Spacer(modifier = Modifier.height(48.dp))

        Button(
            onClick = { viewModel.initLevel(PuzzleRepository.levels3x3.first()) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
            modifier = Modifier.width(200.dp)
        ) {
            Text("Play 3x3")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.initLevel(PuzzleRepository.levels5x5.first()) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C)),
            modifier = Modifier.width(200.dp)
        ) {
            Text("Play 5x5")
        }
    }
}

@Composable
fun GameScreen(viewModel: GameViewModel) {
    val level = viewModel.currentLevel ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = { viewModel.goToMenu() }) {
                Text("Menu")
            }
            if (viewModel.isSolved) {
                Text("SOLVED! 🎋", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(level.gridSize),
                modifier = Modifier.border(2.dp, Color.Black)
            ) {
                itemsIndexed(viewModel.tiles) { index, cell ->
                    TileItem(
                        cell = cell,
                        isSelected = viewModel.selectedIndex == index,
                        onClick = { viewModel.handleTileClick(index) },
                        gridSize = level.gridSize
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .weight(0.6f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("ACROSS", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                level.acrossClues.forEach { clue ->
                    Text("${clue.label}: ${clue.hint}", fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("DOWN", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                level.downClues.forEach { clue ->
                    Text("${clue.label}: ${clue.hint}", fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
        }
    }
}

@Composable
fun TileItem(
    cell: GridCell,
    isSelected: Boolean,
    onClick: () -> Unit,
    gridSize: Int
) {
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .background(
                when {
                    cell.isBlank -> Color.DarkGray
                    cell.isCorrect -> Color(0xFFC8E6C9)
                    isSelected -> Color(0xFFFFF176)
                    else -> Color.White
                }
            )
            .border(0.5.dp, Color.Gray)
            .clickable(enabled = !cell.isBlank && !cell.isCorrect) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (!cell.isBlank) {
            Text(
                text = cell.currentLetter,
                fontSize = if (gridSize > 4) 18.sp else 24.sp,
                fontWeight = FontWeight.Bold,
                color = if (cell.isCorrect) Color(0xFF2E7D32) else Color.Black
            )
        }
    }
}