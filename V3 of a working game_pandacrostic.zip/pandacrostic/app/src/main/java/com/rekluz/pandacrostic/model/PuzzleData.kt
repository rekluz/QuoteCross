package com.rekluz.pandacrostic.model

import kotlinx.serialization.Serializable

@Serializable
data class PuzzleWord(
    val word: String,
    val clue: String
)

@Serializable
data class ClueInfo(
    val label: String,
    val hint: String
)

@Serializable
data class CrissCrossLevel(
    val solvedChars: List<String>,
    val acrossClues: List<ClueInfo> = emptyList(),
    val downClues: List<ClueInfo> = emptyList(),
    val gridSize: Int = 3
)

object PuzzleRepository {
    val levels3x3: List<CrissCrossLevel> = listOf(
        CrissCrossLevel(
            solvedChars = listOf("C", "A", "T", "O", "R", "E", "W", "E", "T"),
            acrossClues = listOf(ClueInfo("R1", "Feline"), ClueInfo("R2", "Metal source")),
            downClues = listOf(ClueInfo("C1", "Farm animal"), ClueInfo("C2", "Are")),
            gridSize = 3
        )
    )

    val levels5x5: List<CrissCrossLevel> = listOf(
        CrissCrossLevel(
            solvedChars = listOf(
                "S", "T", "A", "R", "S",
                "L", "_", "L", "_", "T",
                "O", "C", "E", "A", "N",
                "P", "_", "X", "_", "D",
                "E", "V", "E", "N", "T"
            ),
            acrossClues = listOf(ClueInfo("R1", "Stars"), ClueInfo("R3", "Ocean"), ClueInfo("R5", "Event")),
            downClues = listOf(ClueInfo("C1", "Slope"), ClueInfo("C3", "Alex"), ClueInfo("C5", "End")),
            gridSize = 5
        )
    )
}