package com.rekluz.pandacrostic.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.rekluz.pandacrostic.model.GridPosition
import com.rekluz.pandacrostic.model.HiddenQuoteGrid
import com.rekluz.pandacrostic.model.HiddenQuoteGridGenerator
import com.rekluz.pandacrostic.model.HiddenQuotePuzzle
import com.rekluz.pandacrostic.model.PlacedWord

enum class GameState {
    MENU,
    PLAYING
}

enum class CellDisplayState {
    NORMAL,
    SELECTED,
    GREYED_OUT,
    QUOTE_REVEALED,
    BLANK,
    EMPTY
}

class GameViewModel : ViewModel() {
    var currentState by mutableStateOf(GameState.MENU)
    var currentPuzzle by mutableStateOf<HiddenQuoteGrid?>(null)
    var selectedPositions by mutableStateOf<Set<GridPosition>>(emptySet())
    var solvedWords by mutableStateOf<Set<String>>(emptySet())
    var showRevealPopup by mutableStateOf(false)

    fun initPuzzle(puzzleData: HiddenQuotePuzzle) {
        currentPuzzle = HiddenQuoteGridGenerator.generateGrid(puzzleData)
        selectedPositions = emptySet()
        solvedWords = emptySet()
        showRevealPopup = false
        currentState = GameState.PLAYING
    }

    fun selectGridCell(position: GridPosition) {
        val current = currentPuzzle ?: return

        selectedPositions = if (position in selectedPositions) {
            selectedPositions - position
        } else {
            selectedPositions + position
        }

        checkForMatch()
    }

    fun clearSelection() {
        selectedPositions = emptySet()
    }

    private fun checkForMatch() {
        val current = currentPuzzle ?: return
        val selected = selectedPositions.toList()

        if (selected.isEmpty()) return

        for (placedWord in current.placedWords) {
            if (placedWord.isSolved) continue

            if (positionsMatchWord(selected, placedWord)) {
                solveWord(placedWord.word)
                return
            }
        }
    }

    private fun positionsMatchWord(selected: List<GridPosition>, placedWord: PlacedWord): Boolean {
        if (selected.size != placedWord.positions.size) return false

        if (selected.toSet() == placedWord.positions.toSet()) {
            return true
        }

        if (selected.toSet() == placedWord.positions.reversed().toSet()) {
            return true
        }

        return false
    }

    private fun solveWord(word: String) {
        solvedWords = solvedWords + word
        currentPuzzle = currentPuzzle?.copy(
            placedWords = currentPuzzle!!.placedWords.map { placedWord ->
                if (placedWord.word == word) {
                    placedWord.copy(isSolved = true)
                } else {
                    placedWord
                }
            }
        )

        if (solvedWords.size == (currentPuzzle?.placedWords?.size ?: 0)) {
            showRevealPopup = true
        }

        clearSelection()
    }

    fun goToMenu() {
        currentState = GameState.MENU
        currentPuzzle = null
        selectedPositions = emptySet()
        solvedWords = emptySet()
        showRevealPopup = false
    }

    fun getUnsolvedClues(): List<PlacedWord> {
        return currentPuzzle?.placedWords?.filter { !it.isSolved } ?: emptyList()
    }

    fun getCellDisplayState(position: GridPosition): CellDisplayState {
        val current = currentPuzzle ?: return CellDisplayState.EMPTY
        val letter = current.grid[position.row][position.col]

        if (letter == '_') return CellDisplayState.BLANK

        val solvedWordContainsPos = currentPuzzle?.placedWords
            ?.filter { it.isSolved }
            ?.any { position in it.positions }
            ?: false

        val isQuoteLetter = position in current.quoteLetter

        return when {
            solvedWordContainsPos && !isQuoteLetter -> CellDisplayState.GREYED_OUT
            isQuoteLetter && solvedWordContainsPos -> CellDisplayState.QUOTE_REVEALED
            position in selectedPositions -> CellDisplayState.SELECTED
            else -> CellDisplayState.NORMAL
        }
    }
}