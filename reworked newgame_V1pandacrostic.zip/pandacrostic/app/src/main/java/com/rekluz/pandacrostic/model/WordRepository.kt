package com.rekluz.pandacrostic.model

import android.content.Context
import kotlinx.serialization.json.Json

// This class handles loading the JSON word lists from the assets folder
class WordRepository(private val context: Context) {

    // Configured to ignore extra fields in JSON if you add them later
    private val json = Json {
        ignoreUnknownKeys = true
    }

    /**
     * Loads a list of HiddenQuoteClue objects from a JSON file in the assets folder.
     * @param fileName The name of the file (e.g., "three_letter_words.json")
     */
    fun loadWords(fileName: String): List<HiddenQuoteClue> {
        return try {
            // Open the file from app/src/main/assets/
            val jsonString = context.assets.open(fileName).bufferedReader().use { it.readText() }

            // Parse the string into a List of HiddenQuoteClue objects
            json.decodeFromString<List<HiddenQuoteClue>>(jsonString)
        } catch (e: Exception) {
            // Log the error if the file is missing or formatted incorrectly
            e.printStackTrace()
            emptyList()
        }
    }
}