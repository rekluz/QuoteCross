package com.rekluz.pandacrostic.model

import kotlinx.serialization.Serializable
import kotlin.math.sqrt
import kotlin.random.Random

@Serializable
data class HiddenQuoteClue(
    val word: String,
    val clue: String
)

@Serializable
data class HiddenQuotePuzzle(
    val quoteText: String,
    val quoteAttribution: String,
    val gridLetters: String,
    val clueWords: List<HiddenQuoteClue>
)

data class GridPosition(
    val row: Int,
    val col: Int
)

enum class Direction {
    HORIZONTAL,
    VERTICAL,
    DIAGONAL_DOWN_RIGHT,
    DIAGONAL_DOWN_LEFT,
    HORIZONTAL_REVERSE,
    VERTICAL_REVERSE,
    DIAGONAL_UP_LEFT,
    DIAGONAL_UP_RIGHT
}

data class PlacedWord(
    val word: String,
    val clue: String,
    val startPos: GridPosition,
    val direction: Direction,
    val positions: List<GridPosition>,
    var isSolved: Boolean = false
)

data class HiddenQuoteGrid(
    val grid: Array<Array<Char>>,
    val gridSize: Int,
    val placedWords: List<PlacedWord>,
    val quoteText: String,
    val quoteAttribution: String,
    val quoteLetter: Set<GridPosition>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is HiddenQuoteGrid) return false
        if (!grid.contentDeepEquals(other.grid)) return false
        if (gridSize != other.gridSize) return false
        if (placedWords != other.placedWords) return false
        if (quoteText != other.quoteText) return false
        if (quoteAttribution != other.quoteAttribution) return false
        if (quoteLetter != other.quoteLetter) return false
        return true
    }

    override fun hashCode(): Int {
        var result = grid.contentDeepHashCode()
        result = 31 * result + gridSize
        result = 31 * result + placedWords.hashCode()
        result = 31 * result + quoteText.hashCode()
        result = 31 * result + quoteAttribution.hashCode()
        result = 31 * result + quoteLetter.hashCode()
        return result
    }
}

object HiddenQuoteGridGenerator {
    fun generateGrid(puzzle: HiddenQuotePuzzle): HiddenQuoteGrid {
        val quoteLetters = puzzle.gridLetters.uppercase()
        val gridSize = calculateGridSize(quoteLetters, puzzle.clueWords)

        val grid = Array(gridSize) { Array(gridSize) { ' ' } }
        val placedWords = mutableListOf<PlacedWord>()
        val usedPositions = mutableSetOf<GridPosition>()
        val quotePositions = mutableSetOf<GridPosition>()

        val quotePositionsList = mutableListOf<GridPosition>()
        val random = Random(System.currentTimeMillis())

        // Place quote letters sequentially in reading order so they spell out the quote
        for (i in quoteLetters.indices) {
            var placed = false
            var attempts = 0

            while (!placed && attempts < 100) {
                val row = random.nextInt(gridSize)
                val col = random.nextInt(gridSize)
                val pos = GridPosition(row, col)

                if (pos !in usedPositions) {
                    grid[row][col] = quoteLetters[i]
                    quotePositionsList.add(pos)
                    usedPositions.add(pos)
                    quotePositions.add(pos)
                    placed = true
                }
                attempts++
            }
        }

        val sortedClues = puzzle.clueWords.sortedByDescending { it.word.length }

        for (clue in sortedClues) {
            val word = clue.word.uppercase()
            val directions = Direction.values().toMutableList()
            directions.shuffle(random)

            var placed = false
            var attempts = 0

            while (!placed && attempts < 50) {
                val startRow = random.nextInt(gridSize)
                val startCol = random.nextInt(gridSize)
                val startPos = GridPosition(startRow, startCol)

                for (direction in directions) {
                    val positions = getPositionsForWord(startPos, word, direction, gridSize)

                    if (positions != null && canPlaceWord(positions, grid, usedPositions, word)) {
                        for ((i, pos) in positions.withIndex()) {
                            grid[pos.row][pos.col] = word[i]
                            usedPositions.add(pos)
                        }

                        placedWords.add(
                            PlacedWord(
                                word = word,
                                clue = clue.clue,
                                startPos = startPos,
                                direction = direction,
                                positions = positions
                            )
                        )
                        placed = true
                        break
                    }
                }
                attempts++
            }
        }

        for (row in 0 until gridSize) {
            for (col in 0 until gridSize) {
                if (grid[row][col] == ' ') {
                    grid[row][col] = '_'
                }
            }
        }

        return HiddenQuoteGrid(
            grid = grid,
            gridSize = gridSize,
            placedWords = placedWords,
            quoteText = puzzle.quoteText,
            quoteAttribution = puzzle.quoteAttribution,
            quoteLetter = quotePositions
        )
    }

    private fun calculateGridSize(quoteLetters: String, clueWords: List<HiddenQuoteClue>): Int {
        val totalLetters = quoteLetters.length + clueWords.sumOf { it.word.length }
        val estimatedSize = sqrt(totalLetters.toDouble() * 1.3).toInt()
        return maxOf(estimatedSize, 8)
    }

    private fun getPositionsForWord(
        start: GridPosition,
        word: String,
        direction: Direction,
        gridSize: Int
    ): List<GridPosition>? {
        val positions = mutableListOf<GridPosition>()
        var row = start.row
        var col = start.col

        for (i in word.indices) {
            if (row < 0 || row >= gridSize || col < 0 || col >= gridSize) {
                return null
            }
            positions.add(GridPosition(row, col))

            when (direction) {
                Direction.HORIZONTAL -> col++
                Direction.HORIZONTAL_REVERSE -> col--
                Direction.VERTICAL -> row++
                Direction.VERTICAL_REVERSE -> row--
                Direction.DIAGONAL_DOWN_RIGHT -> {
                    row++
                    col++
                }
                Direction.DIAGONAL_DOWN_LEFT -> {
                    row++
                    col--
                }
                Direction.DIAGONAL_UP_LEFT -> {
                    row--
                    col--
                }
                Direction.DIAGONAL_UP_RIGHT -> {
                    row--
                    col++
                }
            }
        }

        return positions
    }

    private fun canPlaceWord(
        positions: List<GridPosition>,
        grid: Array<Array<Char>>,
        usedPositions: Set<GridPosition>,
        word: String
    ): Boolean {
        for ((i, pos) in positions.withIndex()) {
            if (pos in usedPositions) {
                if (grid[pos.row][pos.col] != word[i]) {
                    return false
                }
            }
        }
        return true
    }
}