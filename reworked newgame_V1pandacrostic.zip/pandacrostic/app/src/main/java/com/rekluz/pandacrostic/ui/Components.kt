package com.rekluz.pandacrostic.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rekluz.pandacrostic.model.GridPosition
import com.rekluz.pandacrostic.model.HiddenQuotePuzzle
import com.rekluz.pandacrostic.viewmodel.CellDisplayState
import com.rekluz.pandacrostic.viewmodel.GameState
import com.rekluz.pandacrostic.viewmodel.GameViewModel

@Composable
fun MainContent(viewModel: GameViewModel) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF0F4F0)
    ) {
        when (viewModel.currentState) {
            GameState.MENU -> MenuScreen(viewModel)
            GameState.PLAYING -> GameScreen(viewModel)
        }
    }
}

@Composable
fun MenuScreen(viewModel: GameViewModel) {
    val infiniteTransition = rememberInfiniteTransition(label = "PandaBreath")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "scale"
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "🐼",
            fontSize = 80.sp,
            modifier = Modifier.graphicsLayer(scaleX = scale, scaleY = scale)
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "PandaCrostic",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF2E7D32)
        )
        Spacer(modifier = Modifier.height(48.dp))

        Button(
            onClick = {
                val testPuzzle = HiddenQuotePuzzle(
                    quoteText = "Set your minds on things above.",
                    quoteAttribution = "Colossians 3:2",
                    gridLetters = "SETYOURMINDSONTHINGSABOVE",
                    clueWords = listOf(
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("SAFE", "Protected from harm"),
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("BACK", "Return to a place"),
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("HERE", "In this location"),
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("SNOW", "Cold white stuff"),
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("HALT", "STOP"),
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("DOG", "Man's best friend"),
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("MANGO", "Tropical fruit"),
                        com.rekluz.pandacrostic.model.HiddenQuoteClue("COME", "To arrive")
                    )
                )
                viewModel.initPuzzle(testPuzzle)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
            modifier = Modifier.width(200.dp)
        ) {
            Text("Play Hidden Quote")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { /* TODO: Add more puzzle types */ },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C)),
            modifier = Modifier.width(200.dp),
            enabled = false
        ) {
            Text("More Coming Soon")
        }
    }
}

@Composable
fun GameScreen(viewModel: GameViewModel) {
    val puzzle = viewModel.currentPuzzle ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = { viewModel.goToMenu() }) {
                Text("Menu")
            }
            Text(
                "Solved: ${viewModel.solvedWords.size}/${puzzle.placedWords.size}",
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .weight(0.5f)
                .fillMaxWidth()
        ) {
            HiddenQuoteGridDisplay(viewModel)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (viewModel.showRevealPopup) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFC8E6C9))
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        "Puzzle Solved!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color(0xFF2E7D32)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = puzzle.quoteText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "— ${puzzle.quoteAttribution}",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = { viewModel.goToMenu() }) {
                        Text("Close")
                    }
                }
            }
        } else {
            Text("Clues:", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            LazyColumn(
                modifier = Modifier
                    .weight(0.5f)
                    .fillMaxWidth()
            ) {
                items(viewModel.getUnsolvedClues()) { placedWord ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F4F0))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = placedWord.clue,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "(${placedWord.word.length} letters)",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HiddenQuoteGridDisplay(viewModel: GameViewModel) {
    val puzzle = viewModel.currentPuzzle ?: return
    val grid = puzzle.grid
    val gridSize = puzzle.gridSize
    val cellSize = 32.dp

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        for (row in 0 until gridSize) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (col in 0 until gridSize) {
                    val position = GridPosition(row, col)
                    val letter = grid[row][col]
                    val displayState = viewModel.getCellDisplayState(position)

                    HiddenQuoteGridCell(
                        letter = letter,
                        displayState = displayState,
                        isSelected = position in viewModel.selectedPositions,
                        onClick = { viewModel.selectGridCell(position) },
                        cellSize = cellSize
                    )
                }
            }
        }
    }
}

@Composable
fun HiddenQuoteGridCell(
    letter: Char,
    displayState: CellDisplayState,
    isSelected: Boolean,
    onClick: () -> Unit,
    cellSize: Dp
) {
    Box(
        modifier = Modifier
            .size(cellSize)
            .background(
                when {
                    displayState == CellDisplayState.BLANK -> Color(0xFFCCCCCC)
                    displayState == CellDisplayState.GREYED_OUT -> Color(0xFFAAAAAA)
                    displayState == CellDisplayState.QUOTE_REVEALED -> Color(0xFFC8E6C9)
                    isSelected && displayState != CellDisplayState.BLANK -> Color(0xFFFFF176)
                    else -> Color.White
                }
            )
            .border(1.dp, Color.Black)
            .clickable(enabled = displayState != CellDisplayState.BLANK) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (letter != '_' && displayState != CellDisplayState.BLANK) {
            Text(
                text = letter.toString(),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = when {
                    displayState == CellDisplayState.GREYED_OUT -> Color.DarkGray
                    displayState == CellDisplayState.QUOTE_REVEALED -> Color(0xFF2E7D32)
                    else -> Color.Black
                }
            )
        }
    }
}

@Composable
fun RevealQuoteDialog(puzzle: com.rekluz.pandacrostic.model.HiddenQuoteGrid, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = {
            Text(
                "Puzzle Solved!",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF2E7D32)
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = puzzle.quoteText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Black,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
                Text(
                    text = "— ${puzzle.quoteAttribution}",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        },
        confirmButton = {
            Button(onClick = { onClose() }) {
                Text("Close")
            }
        }
    )
}